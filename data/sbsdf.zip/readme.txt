-------------------------------------------------------------------
Contents of the file SBSDF.ZIP
-------------------------------------------------------------------

IMP-CODE.TXT            ASCII file of 10-digit HS import codes with
                        associated information.
IMP-STRU.TXT            Layout of IMP-CODE.TXT
EXP-CODE.TXT            ASCII file of 10-digit HS export codes with
                        associated information.
EXP-STRU.TXT            Layout of EXP-CODE.TXT

-------------------------------------------------------------------
QUESTIONS? PROBLEMS? E-MAIL FTDWEBMASTER@CENSUS.GOV.

NOTE: This update was to update the concordance between HS/Schedule 
      B codes and the other classification systems (i.e. SIC, SITC, 
      NAICS).
-------------------------------------------------------------------
